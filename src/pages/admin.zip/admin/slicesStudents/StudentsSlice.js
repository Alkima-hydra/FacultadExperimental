import { createSlice } from '@reduxjs/toolkit';
import {
  fetchEstudiantes,
  fetchAllEstudiantes,
  fetchEstudianteById,
  createEstudiante,
  updateEstudiante,
  deleteEstudiante,
  buscarEstudiantes,
} from './StudentsThunk';

const initialState = {
  Estudiantes: [],
  totalItems: 0,
  totalPages: 1,
  currentPage: 1,

  allEstudiantes: [],
  Estudianteseleccionado: null,

  isLoading: false,
  isLoadingAll: false,
  isLoadingById: false,
  isCreating: false,
  isUpdating: false,
  isDeleting: false,
  isSearching: false,
  error: null,
};

const EstudiantesSlice = createSlice({
  name: 'Estudiantes',
  initialState,
  reducers: {
    clearError(state) {
      state.error = null;
    },
    clearEstudianteseleccionado(state) {
      state.Estudianteseleccionado = null;
    },
    resetPagination(state) {
      state.Estudiantes = [];
      state.totalItems = 0;
      state.totalPages = 1;
      state.currentPage = 1;
    },
  },
  extraReducers: (builder) => {
    builder
      // fetchEstudiantes (paginado)
      .addCase(fetchEstudiantes.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchEstudiantes.fulfilled, (state, action) => {
        state.isLoading = false;
        state.Estudiantes = action.payload.Estudiantes;
        state.totalItems = action.payload.totalItems;
        state.totalPages = action.payload.totalPages;
        state.currentPage = action.payload.currentPage;
      })
      .addCase(fetchEstudiantes.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload?.message || 'Error al cargar Estudiantes';
      })

      // fetchAllEstudiantes
      .addCase(fetchAllEstudiantes.pending, (state) => {
        state.isLoadingAll = true;
        state.error = null;
      })
      .addCase(fetchAllEstudiantes.fulfilled, (state, action) => {
        state.isLoadingAll = false;
        state.allEstudiantes = action.payload;
      })
      .addCase(fetchAllEstudiantes.rejected, (state, action) => {
        state.isLoadingAll = false;
        state.error = action.payload?.message || 'Error al cargar todas los Estudiantes';
      })

      // fetchEstudianteById 
      .addCase(fetchEstudianteById.pending, (state) => {
        state.isLoadingById = true;
        state.error = null;
      })
      .addCase(fetchEstudianteById.fulfilled, (state, action) => {
        state.isLoadingById = false;
        state.Estudianteseleccionado = action.payload;
      })
      .addCase(fetchEstudianteById.rejected, (state, action) => {
        state.isLoadingById = false;
        state.error = action.payload?.message || 'Error al cargar el Estudiante';
      })

      // createEstudiante
      .addCase(createEstudiante.pending, (state) => {
        state.isCreating = true;
        state.error = null;
      })
      .addCase(createEstudiante.fulfilled, (state, action) => {
        state.isCreating = false;
        const nueva = action.payload;
        // Si ya hay lista paginada cargada, insertamos al inicio (opcional)
        if (Array.isArray(state.Estudiantes)) {
          state.Estudiantes = [nueva, ...state.Estudiantes];
          state.totalItems = (state.totalItems || 0) + 1;
        }
        state.Estudianteseleccionado = nueva;
      })
      .addCase(createEstudiante.rejected, (state, action) => {
        state.isCreating = false;
        state.error = action.payload?.message || 'Error al crear Estudiante';
      })

      // updateEstudiante
      .addCase(updateEstudiante.pending, (state) => {
        state.isUpdating = true;
        state.error = null;
      })
      .addCase(updateEstudiante.fulfilled, (state, action) => {
        state.isUpdating = false;
      })
      .addCase(updateEstudiante.rejected, (state, action) => {
        state.isUpdating = false;
        state.error = action.payload?.message || 'Error al actualizar Estudiante';
      })

      // deleteEstudiante
      .addCase(deleteEstudiante.pending, (state) => {
        state.isDeleting = true;
        state.error = null;
      })
      .addCase(deleteEstudiante.fulfilled, (state, action) => {
        state.isDeleting = false;
        const deletedId = action.payload?.id;
        if (deletedId !== undefined) {
          state.Estudiantes = state.Estudiantes.filter(p => p.id_estudiante !== deletedId);
        }
        if (state.Estudianteseleccionado?.id_estudiante === deletedId) {
          state.Estudianteseleccionado = null;
        }
        state.totalItems = Math.max(0, (state.totalItems || 1) - 1);
      })
      .addCase(deleteEstudiante.rejected, (state, action) => {
        state.isDeleting = false;
        state.error = action.payload?.message || 'Error al eliminar Estudiante';
      })
      .addCase(buscarEstudiantes.pending, (state) => {
        state.isSearching = true;
        state.error = null;
      })
      .addCase(buscarEstudiantes.fulfilled, (state, action) => {
        state.isSearching = false;
        state.Estudiantes   = action.payload?.estudiantes  ?? [];
        state.totalItems    = action.payload?.totalItems   ?? 0;
        state.totalPages    = action.payload?.totalPages   ?? 1;
        state.currentPage   = action.payload?.currentPage  ?? 1;
      })
      .addCase(buscarEstudiantes.rejected, (state, action) => {
        state.isSearching = false;
        state.error = action.payload?.message || 'Error al buscar Estudiantes';
      })
  },
});

// Acciones síncronas
export const { clearError, clearEstudianteseleccionado, resetPagination } = EstudiantesSlice.actions;

// Selectores
// Nota: en rootReducer el slice está montado como `students`
export const selectEstudiantes = (state) => state?.students?.Estudiantes || [];
export const selectTotalItems = (state) => state?.students?.totalItems ?? 0;
export const selectTotalPages = (state) => state?.students?.totalPages ?? 1;
export const selectCurrentPage = (state) => state?.students?.currentPage ?? 1;
export const selectAllEstudiantes = (state) => state?.students?.allEstudiantes || [];
export const selectEstudianteseleccionado = (state) => state?.students?.Estudianteseleccionado ?? null;

export const selectIsLoading = (state) => Boolean(state?.students?.isLoading);
export const selectIsLoadingAll = (state) => Boolean(state?.students?.isLoadingAll);
export const selectIsLoadingById = (state) => Boolean(state?.students?.isLoadingById);
export const selectIsSearching = (state) => Boolean(state?.students?.isSearching);
export const selectError = (state) => state?.students?.error ?? null;
export const selectIsCreating = (state) => Boolean(state?.students?.isCreating);
export const selectIsUpdating = (state) => Boolean(state?.students?.isUpdating);
export const selectIsDeleting = (state) => Boolean(state?.students?.isDeleting);

// Exportar reducer
export const EstudiantesReducer = EstudiantesSlice.reducer;
export default EstudiantesSlice.reducer;